import Link from 'next/link';

const categories = [
  {
    id: 'electronics',
    name: 'Electronics',
    description: 'Latest gadgets and tech',
    image: '/categories/electronics.jpg',
    color: 'bg-blue-500'
  },
  {
    id: 'clothing',
    name: 'Clothing',
    description: 'Fashion and apparel',
    image: '/categories/clothing.jpg',
    color: 'bg-purple-500'
  },
  {
    id: 'home',
    name: 'Home & Garden',
    description: 'Everything for your home',
    image: '/categories/home.jpg',
    color: 'bg-green-500'
  },
  {
    id: 'books',
    name: 'Books',
    description: 'Knowledge and entertainment',
    image: '/categories/books.jpg',
    color: 'bg-orange-500'
  }
];

const CategoriesSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Shop by Category
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our diverse range of products carefully curated from Ethiopian businesses
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/categories/${category.id}`}
              className="group block"
            >
              <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className={`${category.color} h-32 flex items-center justify-center`}>
                  <span className="text-white text-4xl font-bold">
                    {category.name.charAt(0)}
                  </span>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">
                    {category.name}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {category.description}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;