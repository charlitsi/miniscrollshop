import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">MiniscrollShop</h3>
            <p className="text-gray-300 mb-4">
              Your trusted online marketplace for quality products in Ethiopia.
            </p>
            <p className="text-gray-300">
              Supporting local businesses and communities.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-300 hover:text-white">About Us</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-white">Contact</Link></li>
              <li><Link href="/shipping" className="text-gray-300 hover:text-white">Shipping Info</Link></li>
              <li><Link href="/returns" className="text-gray-300 hover:text-white">Returns</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><Link href="/categories/electronics" className="text-gray-300 hover:text-white">Electronics</Link></li>
              <li><Link href="/categories/clothing" className="text-gray-300 hover:text-white">Clothing</Link></li>
              <li><Link href="/categories/home" className="text-gray-300 hover:text-white">Home & Garden</Link></li>
              <li><Link href="/categories/books" className="text-gray-300 hover:text-white">Books</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-2 text-gray-300">
              <p>📧 info@miniscrollshop.et</p>
              <p>📞 +251-11-123-4567</p>
              <p>📍 Addis Ababa, Ethiopia</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            © 2024 MiniscrollShop. All rights reserved. | Made in Ethiopia 🇪🇹
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;