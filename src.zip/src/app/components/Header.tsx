'use client';
import { useState } from 'react';
import Link from 'next/link';
import { ShoppingCartIcon, UserIcon, HeartIcon, Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="text-2xl font-bold text-green-600">
            MiniscrollShop
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-green-600">Home</Link>
            <Link href="/products" className="text-gray-700 hover:text-green-600">Products</Link>
            <Link href="/categories" className="text-gray-700 hover:text-green-600">Categories</Link>
            <Link href="/about" className="text-gray-700 hover:text-green-600">About</Link>
            <Link href="/contact" className="text-gray-700 hover:text-green-600">Contact</Link>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <Link href="/wishlist" className="text-gray-700 hover:text-green-600">
              <HeartIcon className="h-6 w-6" />
            </Link>
            <Link href="/cart" className="text-gray-700 hover:text-green-600 relative">
              <ShoppingCartIcon className="h-6 w-6" />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                0
              </span>
            </Link>
            <Link href="/profile" className="text-gray-700 hover:text-green-600">
              <UserIcon className="h-6 w-6" />
            </Link>
            
            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <XMarkIcon className="h-6 w-6" />
              ) : (
                <Bars3Icon className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-2">
              <Link href="/" className="text-gray-700 hover:text-green-600 py-2">Home</Link>
              <Link href="/products" className="text-gray-700 hover:text-green-600 py-2">Products</Link>
              <Link href="/categories" className="text-gray-700 hover:text-green-600 py-2">Categories</Link>
              <Link href="/about" className="text-gray-700 hover:text-green-600 py-2">About</Link>
              <Link href="/contact" className="text-gray-700 hover:text-green-600 py-2">Contact</Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;