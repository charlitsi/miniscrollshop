export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'women' | 'men' | 'accessories' | 'home';
  images: string[];
  sizes: string[];
  inStock: boolean;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  _id: string;
  name: string;
  email: string;
  password: string;
  role: 'customer' | 'admin';
  address?: {
    street: string;
    city: string;
    region: string;
    country: string;
  };
  createdAt: Date;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
}

export interface Order {
  _id: string;
  user: User;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  paymentStatus: 'pending' | 'paid' | 'failed';
  shippingAddress: {
    street: string;
    city: string;
    region: string;
    country: string;
  };
  createdAt: Date;
}